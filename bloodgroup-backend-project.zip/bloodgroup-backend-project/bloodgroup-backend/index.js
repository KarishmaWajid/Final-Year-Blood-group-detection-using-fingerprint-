// index.js
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mysql = require('mysql2');

const app = express();
const port = 3001;

app.use(cors());
app.use(bodyParser.json());

// MySQL connection setup
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root', // change this
  database: 'blood_group_db'       // make sure this DB exists
});

db.connect(err => {
  if (err) {
    console.error('MySQL connection error:', err);
  } else {
    console.log('Connected to MySQL');
  }
});

// Create table if not exists
db.query(`
  CREATE TABLE IF NOT EXISTS predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    blood_group VARCHAR(10),
    predicted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  )
`);

// API endpoint to store prediction
app.post('/store', (req, res) => {
  const { blood_group } = req.body;

  if (!blood_group) {
    return res.status(400).json({ error: 'Blood group is required' });
  }

  const query = 'INSERT INTO predictions (blood_group) VALUES (?)';
  db.query(query, [blood_group], (err, result) => {
    if (err) {
      console.error('Error storing data:', err);
      res.status(500).json({ error: 'Failed to store blood group' });
    } else {
      res.status(200).json({ message: 'Blood group stored successfully' });
    }
  });
});

app.listen(port, () => {
  console.log(`Node server running on http://localhost:${port}`);
});
